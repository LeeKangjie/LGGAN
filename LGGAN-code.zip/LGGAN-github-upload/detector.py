
import torch
import numpy as np
from PIL import Image
import torch.nn as nn
import matplotlib.pyplot as plt
from torchvision.utils import save_image
import torch.nn.functional as F
from torch.autograd import Variable

class detector(nn.Module):
    
    def __init__(self,net):
        super(detector, self).__init__()
        self.centernet=net

    def forward(self,input):
        output=input
        boxes=[]

        for i in range(input.shape[0]):
            
            save_image(input[i].view(28,28), f"1.jpg")
            image=Image.open("1.jpg")    

            image2 = image.resize((560,560), Image.BICUBIC)
            box = self.centernet.detect_image(image2,Return_boxes=True)

            boxes.append(box)
        
        canvas=np.zeros((1,784),dtype=float)
        R=np.reshape(canvas,(28,28))

        for i in range(len(boxes)):
            R[:,:]=0
            for j in range(len(boxes[i])):
                top, left, bottom, right = boxes[i][j]
                px=int(top//20)
                py=int(left//20)
                if bottom-top>20*20*0.8:
                    R[px:px+20,py:py+5]=1
                elif right-left>10*20*0.8:
                    R[px:px+5,py:py+10]=1
                else:
                    R[px:px+5,py:py+5]=1
            np_output=np.reshape(R,(1,784))
            output[i]=torch.tensor(np_output)
    
        return output

class spdetector(nn.Module):
    def __init__(self,K1,K2,K3):
        super(spdetector, self).__init__()
        self.K1=K1
        self.K2=K2
        self.K3=K3
    
    def forward(self,input,num):

        output=torch.zeros(input.shape[0],28*28).cuda()    
        for i in range(input.shape[0]):

            R=Variable(torch.reshape(input[i],(1,1,28,28)),requires_grad=True)
            R0=torch.zeros(1,1,28,28)
            if num == 1:

                p=F.conv2d(R,self.K1)
                m=torch.argmax(p.squeeze(0).squeeze(0))

                R0[0][0][m//p.shape[3]:m//p.shape[3]+20,m%p.shape[3]:m%p.shape[3]+5]=1.0
                C1=Variable(torch.Tensor(R0),requires_grad=True) 
                R=C1
            elif num == 2:

                p=F.conv2d(R,self.K2)
                m=torch.argmax(p.squeeze(0).squeeze(0))

                R0[0][0][m//p.shape[3]:m//p.shape[3]+5,m%p.shape[3]:m%p.shape[3]+10]=1.0
                C2=Variable(torch.Tensor(R0),requires_grad=True) 
                R=C2
            elif num == 3:

                p=F.conv2d(R,self.K3)
                m=torch.argmax(p.squeeze(0).squeeze(0))

                R0[0][0][m//p.shape[3]:m//p.shape[3]+5,m%p.shape[3]:m%p.shape[3]+5]=1.0
                C3=Variable(torch.Tensor(R0),requires_grad=True) 
                R=C3

            output[i]=torch.reshape(R,(1,28*28))
        return output
 

class denoiser(nn.Module):
    def __init__(self,net):
        super(denoiser, self).__init__()
        self.DAE=net

    def forward(self,inputs):
        outputs=self.DAE(inputs) 

        return outputs

    def to3channel(self,X,num):
        X=self.DAE(X)
        R=torch.reshape(255*X,(28,28,1))
        R[R<0]=0
        R0=torch.zeros((28,28,1)).cuda()
        if num==1:
            out=torch.cat((220/255*R,20/255*R,60/255*R), axis=2)
        elif num==2:
            out=torch.cat((R0,R,R0), axis=2)
        elif num==3:
            out=torch.cat((R0,191/255*R,R), axis=2)
        out=torch.Tensor.int(out)
        return out
