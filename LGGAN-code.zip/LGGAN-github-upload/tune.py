import torch
import numpy as np
from PIL import Image
import torch.nn as nn
from centernet_pytorch_main.centernet import CenterNet

model_path='./centernet_pytorch_main/logs/Epoch100-Total_Loss0.9128-Val_Loss0.4900.pth'
centernet = CenterNet(model_path)

class tune(nn.Module):

    def __init__(self):
        super(tune, self).__init__()
        self.centernet=centernet

    def forward(self,input):
        boxes=[]
        np_input=input.cpu().detach().numpy()
        np_input=np.array(np.uint8(np_input))
        image=Image.fromarray(np_input)
        #image.show()
        image2 = image.resize((560,560), Image.BICUBIC)
        #image2.show()
        img,box = self.centernet.detect_image(image2,Return_boxes=True)
        #img.show()
        #box = self.centernet.detect_image(image2,Return_boxes=True)
        boxes.append(box)

        #boxes=self.adjust_boxes(boxes)
        canvas=torch.zeros((28,28,3))
        binary_canvas=torch.zeros((28,28,1))

        C_number=np.zeros((3))

        for j in range(len(boxes[0])):
            top, left, bottom, right = boxes[0][j]
            px=int(top//20)
            py=int(left//20)
            if bottom-top>12*20*0.8:
                C_number[0]+=1
                if C_number[0]<2:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+12,py:py+7]=255
                    canvas=canvas+torch.cat((220/255*R,20/255*R,60/255*R), axis=2)
                    binary_canvas=binary_canvas+R/255
            elif right-left>10*20*0.8:#Component2
                C_number[1]+=1
                if C_number[1]<3:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+5,py:py+10]=255
                    canvas=canvas+torch.cat((R0,R,R0), axis=2)
                    binary_canvas=binary_canvas+R/255
            elif right-left>5*20*0.7 and bottom-top>5*20*0.7:
                C_number[2]+=1
                if C_number[2]<8:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+5,py:py+5]=255
                    canvas=canvas+torch.cat((R0,191/255*R,R), axis=2)
                    binary_canvas=binary_canvas+R/255
        RGB_output=torch.Tensor.int(canvas)
        RGB_output=RGB_output.reshape(1,28*28*3)
        
        one = torch.ones_like(binary_canvas)
        binary_output=torch.where(binary_canvas > 0, one, binary_canvas)
        binary_output=binary_output.reshape(1,28*28)
    
        return RGB_output,binary_output

    def adjust_boxes(self,input):
        output=input #design sapce exploration
        for i in range(len(input)):
            for j in range(len(input[i])):
                top1,left1,bottom1,right1=input[i][j]
    
                xishu=0.5
                if (top1<2.5*20):
                    vertical_move=2.5*20*(np.random.rand(1))
                elif (560-bottom1<2.5*20):
                    vertical_move=2.5*20*(np.random.rand(1)-1)
                else:
                    vertical_move=2.5*20*(np.random.rand(1)-0.5)*2

                if (left1<2.5*20):
                    horizontal_move=2.5*20*(np.random.rand(1))
                elif (560-right1<2.5*20):
                    horizontal_move=2.5*20*(np.random.rand(1)-1)
                else:
                    horizontal_move=2.5*20*(np.random.rand(1)-0.5)*2
                
                top1+=vertical_move*xishu
                bottom1+=vertical_move*xishu
                left1+=horizontal_move*xishu
                right1+=horizontal_move*xishu
                input[i][j]=top1,left1,bottom1,right1


        for i in range(len(input)):
            for j in range(len(input[i])):
                for k in range(j):
                    top1, left1, bottom1, right1 = output[i][j]
                    top2, left2, bottom2, right2 = output[i][k]
                    a=right1<left2
                    b=bottom1<top2
                    c=right2<left1
                    d=bottom2<top1
                    if not(right1<left2 or bottom1<top2 or right2<left1 or bottom2<top1):

                        left_move=right1-left2+20
                        right_move=right2-left1+20
                        top_move=bottom1-top2+20
                        bottom_move=bottom2-top1+20

                        if (left_move<right_move and left_move<top_move and left_move<bottom_move):
                            output[i][j]= top1, left1-left_move, bottom1, right1-left_move
                        if (right_move<left_move and right_move<top_move and right_move<bottom_move):
                            output[i][j]= top1, left1+right_move, bottom1, right1+right_move
                        if (top_move<left_move and top_move<right_move and top_move<bottom_move):
                            output[i][j]= top1-top_move, left1, bottom1-top_move, right1
                        else:
                            output[i][j]= top1+bottom_move, left1, bottom1+bottom_move, right1

        return output

class tune_LGD3(nn.Module):

    def __init__(self):
        super(tune_LGD3, self).__init__()
        self.centernet=centernet

    def forward(self,input):
        boxes=[]
        np_input=input.cpu().detach().numpy()
        np_input=np.array(np.uint8(np_input))
        image=Image.fromarray(np_input)
        #image.show()
        image2 = image.resize((560,560), Image.BICUBIC)
        #image2.show()
        img,box = self.centernet.detect_image(image2,Return_boxes=True)
        #img.show()
        #box = self.centernet.detect_image(image2,Return_boxes=True)
        boxes.append(box)

        #boxes=self.adjust_boxes(boxes)
        canvas=torch.zeros((28,28,3))
        binary_canvas=torch.zeros((28,28,1))

        C_number=np.zeros((3))

        for j in range(len(boxes[0])):
            top, left, bottom, right = boxes[0][j]
            px=int(top//20)
            py=int(left//20)
            S1=0.0
            S2=0.0
            if bottom-top>12*20*0.8:
                S1=1/((left-18*20)*(left-18*20)+1)+1/((top-8*20)*(top-8*20)+1)
                C_number[0]+=1
                if C_number[0]<2:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+12,py:py+7]=255
                    canvas=canvas+torch.cat((220/255*R,20/255*R,60/255*R), axis=2)
                    binary_canvas=binary_canvas+R/255
            elif right-left>10*20*0.8:
                C_number[1]+=1
                if C_number[1]<1:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+5,py:py+10]=255
                    canvas=canvas+torch.cat((R0,R,R0), axis=2)
                    binary_canvas=binary_canvas+R/255
            elif right-left>5*20*0.7 and bottom-top>5*20*0.7:
                S2=1/((left-2*20)*(left-2*20)+1)+1/((top-11*20)*(top-11*20)+1)
                C_number[2]+=1
                if C_number[2]<2:
                    R=torch.zeros((28,28,1))
                    R0=torch.zeros((28,28,1))
                    R[px:px+5,py:py+5]=255
                    canvas=canvas+torch.cat((R0,191/255*R,R), axis=2)
                    binary_canvas=binary_canvas+R/255
        RGB_output=torch.Tensor.int(canvas)
        RGB_output=RGB_output.reshape(1,28*28*3)
        
        one = torch.ones_like(binary_canvas)
        binary_output=torch.where(binary_canvas > 0, one, binary_canvas)
        binary_output=binary_output.reshape(1,28*28)

        score=S1+S2
        return RGB_output,binary_output,score

    def adjust_boxes(self,input):
        output=input#design sapce exploration

        for i in range(len(input)):
            for j in range(len(input[i])):
                top1,left1,bottom1,right1=input[i][j]
 
                xishu=0.1
                if (top1<2.5*20):
                    vertical_move=2.5*20*(np.random.rand(1))
                elif (560-bottom1<2.5*20):
                    vertical_move=2.5*20*(np.random.rand(1)-1)
                else:
                    vertical_move=2.5*20*(np.random.rand(1)-0.5)*2

                if (left1<2.5*20):
                    horizontal_move=2.5*20*(np.random.rand(1))
                elif (560-right1<2.5*20):
                    horizontal_move=2.5*20*(np.random.rand(1)-1)
                else:
                    horizontal_move=2.5*20*(np.random.rand(1)-0.5)*2
                
                top1+=vertical_move*xishu
                bottom1+=vertical_move*xishu
                left1+=horizontal_move*xishu
                right1+=horizontal_move*xishu
                input[i][j]=top1,left1,bottom1,right1


        for i in range(len(input)):
            for j in range(len(input[i])):
                for k in range(j):
                    top1, left1, bottom1, right1 = output[i][j]
                    top2, left2, bottom2, right2 = output[i][k]
                    a=right1<left2
                    b=bottom1<top2
                    c=right2<left1
                    d=bottom2<top1
                    if not(right1<left2 or bottom1<top2 or right2<left1 or bottom2<top1):

                        left_move=right1-left2+20
                        right_move=right2-left1+20
                        top_move=bottom1-top2+20
                        bottom_move=bottom2-top1+20

                        if (left_move<right_move and left_move<top_move and left_move<bottom_move):
                            output[i][j]= top1, left1-left_move, bottom1, right1-left_move
                        if (right_move<left_move and right_move<top_move and right_move<bottom_move):
                            output[i][j]= top1, left1+right_move, bottom1, right1+right_move
                        if (top_move<left_move and top_move<right_move and top_move<bottom_move):
                            output[i][j]= top1-top_move, left1, bottom1-top_move, right1
                        else:
                            output[i][j]= top1+bottom_move, left1, bottom1+bottom_move, right1
    
        return output
