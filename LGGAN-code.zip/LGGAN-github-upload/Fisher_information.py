import numpy as np
import matplotlib.pyplot as plt

def gaussian2D(shape, sigma=1):
    m, n = [(ss - 1.) / 2. for ss in shape]
    y, x = np.ogrid[-m:m + 1, -n:n + 1]
    h = np.exp(-(x * x + y * y) / (2 * sigma * sigma))
    h[h < np.finfo(h.dtype).eps * h.max()] = 0
    return h

def draw_gaussian(center,sigma_chu): 
    radius=28*2
    diameter=2 * radius + 1
    gaussian = gaussian2D((diameter, diameter), sigma=diameter / sigma_chu)
    score_map=np.zeros((28,28))
    height, width = 28,28
    for i in range(len(center)):
        x, y = int(center[i][0]), int(center[i][1])
        left, right = min(x, radius), min(width - x, radius + 1)
        top, bottom = min(y, radius), min(height - y, radius + 1)
        masked_gaussian = gaussian[radius - top:radius + bottom, radius - left:radius + right]
        score_map=masked_gaussian+score_map
    return score_map


center2=[[13,7],[20,2],[20,9],[12,13],[12,19],[5,15],[5,23],[6,5],[13,25]]
center=[[3,4],[4,11],[5,17],[10,21],[17,21],[21,17],[21,11],[22,4]]

center_true=[[5,4],[13,4],[21,4],[21,10],[13,12],[5,16],[5,22],[13,22],[21,24]]
sigma_chu=64
hist=draw_gaussian(center,sigma_chu)
hist2=draw_gaussian(center2,sigma_chu)


def FI_calc(center_true,Z):
    FI=np.zeros((len(center_true)))
    for i in range(len(center_true)):
        Fa=Z[center_true[i][1],center_true[i][0]]#x,y
        Fc=Z[center_true[i][1],center_true[i][0]+1]#x,y+1
        Fe=Z[center_true[i][1]+1,center_true[i][0]]#x+1,y
        Fb=Z[center_true[i][1],center_true[i][0]-1]#x,y-1
        Fd=Z[center_true[i][1]-1,center_true[i][0]]#x-1,y
        cosphi=center_true[i][1]/np.sqrt(center_true[i][1]*center_true[i][1]+center_true[i][0]*center_true[i][0])
        sinphi=center_true[i][0]/np.sqrt(center_true[i][1]*center_true[i][1]+center_true[i][0]*center_true[i][0])
        FI[i]=np.abs((Fc-2*Fa+Fb)*cosphi+(Fe-2*Fa+Fd)*sinphi)
    return FI
x=range(len(center_true))
y1=FI_calc(center_true,hist)
y2=FI_calc(center_true,hist2)

plt.figure()
plt.plot(x,y1,label='good_observation')
plt.plot(x,y2,label='bad_observation')
plt.xlabel('theta')
plt.ylabel('FI')
plt.legend(loc=4)
plt.grid(True)
plt.show()
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
C = plt.contour(np.flipud(hist), 8, cmap='jet')
plt.clabel(C, inline=True, fmt='%1.2f')
plt.gca().set_aspect(1)
plt.show()

plt.imshow(hist,cmap='Blues')
plt.colorbar()

center=[[13,21],[20,26],[20,19],[12,15],[12,9],[5,13],[5,5],[6,23],[13,3]]
import matplotlib.pyplot as plt
fig = plt.figure()
for i in range(len(center)):
    x,y=center[i][0],center[i][1]
    width,length=5,5
    rect = plt.Rectangle((x-width/2,y-length/2),width,length,fill=False,edgecolor='dodgerblue', linewidth=1)
    plt.gca().add_patch(rect)
    plt.gca().plot(x,y,'o',color='black',markersize=3)

plt.gca().set_aspect(1)
plt.xlim((0, 28))
plt.ylim((0, 28))
plt.show()

