import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
from PIL import Image

'''
class generator(nn.Module):
    # initializers
    def __init__(self, input_size=100, n_class = 784):
        super(generator, self).__init__()
        #试下32-100-256-512-1024-784
        #self.fc0 = nn.Linear(32, 100)
        self.fc1 = nn.Linear(100, 256)
        self.fc2 = nn.Linear(self.fc1.out_features, 512)
        self.fc3 = nn.Linear(self.fc2.out_features, 1024)
        self.fc4 = nn.Linear(self.fc3.out_features, n_class)

    # forward method
    def forward(self, input):
        #x = F.leaky_relu(self.fc0(input), 0.2)
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.leaky_relu(self.fc3(x), 0.2)
        x = F.tanh(self.fc4(x))
        #x = F.sigmoid(self.fc4(x))

        return x
'''

class generator(nn.Module):
    # initializers
    def __init__(self, input_size=100, n_class = 784):
        super(generator, self).__init__()
        self.deconv1 = nn.ConvTranspose2d(100, 512, 4, 1, 0)
        self.deconv1_bn = nn.BatchNorm2d(512)
        self.deconv2 = nn.ConvTranspose2d(512, 256, 4, 2, 1)
        self.deconv2_bn = nn.BatchNorm2d(256)
        self.deconv3 = nn.ConvTranspose2d(256, 128, 4, 2, 1)
        self.deconv3_bn = nn.BatchNorm2d(128)
        self.deconv4 = nn.ConvTranspose2d(128, 1, 4, 2, 3)
        for m in self._modules:
                normal_init(self._modules[m], 0.0, 0.02)
    # forward method
    def forward(self, input):
        input=input.view(-1, 100, 1, 1)
        x = F.relu(self.deconv1_bn(self.deconv1(input)))
        x = F.relu(self.deconv2_bn(self.deconv2(x)))
        x = F.relu(self.deconv3_bn(self.deconv3(x)))
        x = F.tanh(self.deconv4(x))

        return x


class discriminator(nn.Module):
    # initializers
    def __init__(self, input_size=784, n_class=1):
        super(discriminator, self).__init__()
        self.fc1 = nn.Linear(input_size, 1024)
        self.fc2 = nn.Linear(self.fc1.out_features, 512)
        self.fc3 = nn.Linear(self.fc2.out_features, 256)
        self.fc4 = nn.Linear(self.fc3.out_features, n_class)

    # forward method
    def forward(self, input):
        input=input.view(-1,28*28)
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.dropout(x, 0.3)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.dropout(x, 0.3)
        x = F.leaky_relu(self.fc3(x), 0.2)
        x = F.dropout(x, 0.3)
        x = F.sigmoid(self.fc4(x))

        return x

def normal_init(m, mean, std):
    if isinstance(m, nn.ConvTranspose2d) or isinstance(m, nn.Conv2d):
        m.weight.data.normal_(mean, std)
        m.bias.data.zero_()

# class discriminator(nn.Module):
#     # initializers
#     def __init__(self, input_size=784, n_class=1):
#         super(discriminator, self).__init__()
#         self.conv1 = nn.Conv2d(1, 128, 4, 2, 3)
#         self.conv2 = nn.Conv2d(128, 256, 4, 2, 1)
#         self.conv2_bn = nn.BatchNorm2d(256)
#         self.conv3 = nn.Conv2d(256, 512, 4, 2, 1)
#         self.conv3_bn = nn.BatchNorm2d(512)
#         self.conv4 = nn.Conv2d(512, 1, 4, 2, 0)
#         for m in self._modules:
#             normal_init(self._modules[m], 0.0, 0.02)


#     # forward method
#     def forward(self, input):
#         input=input.view(-1, 1, 28, 28)
#         x = F.leaky_relu(self.conv1(input), 0.2)
#         x = F.leaky_relu(self.conv2_bn(self.conv2(x)), 0.2)
#         x = F.leaky_relu(self.conv3_bn(self.conv3(x)), 0.2)
#         x = F.sigmoid(self.conv4(x))

#         return x


class Biggenerator(nn.Module):
    # initializers
    def __init__(self, G1, G2, G3, G4, G5, Detector, input_size=100, n_class=500):
        super(Biggenerator, self).__init__()
        self.fc1 = nn.Linear(input_size, 256)
        self.fc2 = nn.Linear(256, 500)
        self.fc3 = nn.Linear(500,700)
        
        self.G1=G1.eval()
        self.G2=G2.eval()
        self.G3=G3.eval()
        self.G4=G4.eval()
        self.G5=G5.eval()
        self.Detector=Detector
        
    # forward method
    def forward(self, input):
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.tanh(self.fc3(x))
        #x = F.tanh(self.fc2(x))
        
        X1=x[:,0:100]
        X2=x[:,100:200]
        X3=x[:,200:300]
        X4=x[:,300:400]
        X5=x[:,400:500]

        X6=x[:,500:600]
        X7=x[:,600:700]
        
        Y1=self.G3(X1)
        Y2=self.G3(X2)
        Y3=self.G3(X3)
        Y4=self.G3(X4)
        Y5=self.G3(X5)
        Y6=self.G3(X6)
        Y7=self.G3(X7)
        X=self.Detector(Y1)+self.Detector(Y2)+self.Detector(Y3)+self.Detector(Y4)+self.Detector(Y5)+self.Detector(Y6)+self.Detector(Y7)#这里的detector是denoise
        
        '''
        Y1=self.G1(X1)
        Y2=self.G2(X2)
        Y3=self.G3(X3)
        Y4=self.G4(X4)
        Y5=self.G5(X5)
        #X=Y1+Y2+Y3+Y4+Y5
        #X=self.Detector(Y1,1)+self.Detector(Y2,2)+self.Detector(Y3,3)+self.Detector(Y4,2)+self.Detector(Y5,3)
        X=self.Detector(Y1)+self.Detector(Y2)+self.Detector(Y3)+self.Detector(Y4)+self.Detector(Y5)
        '''
        return X
    
    def RGBforward(self,input):
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.tanh(self.fc3(x))
        #x = F.tanh(self.fc2(x))
        
        X1=x[:,0:100]
        X2=x[:,100:200]
        X3=x[:,200:300]
        X4=x[:,300:400]
        X5=x[:,400:500]
        
        X6=x[:,500:600]
        X7=x[:,600:700]
        
        
        Y1=self.G3(X1)
        Y2=self.G3(X2)
        Y3=self.G3(X3)
        Y4=self.G3(X4)
        Y5=self.G3(X5)
        Y6=self.G3(X6)
        Y7=self.G3(X7)        
        X=self.Detector.to3channel(Y1,3)+self.Detector.to3channel(Y2,3)+self.Detector.to3channel(Y3,3)+self.Detector.to3channel(Y4,3)+self.Detector.to3channel(Y5,3)+self.Detector.to3channel(Y6,3)+self.Detector.to3channel(Y7,3)
        
        '''
        Y1=self.G1(X1)
        Y2=self.G2(X2)
        Y3=self.G3(X3)
        Y4=self.G4(X4)
        Y5=self.G5(X5)
        X=self.Detector.to3channel(Y1,1)+self.Detector.to3channel(Y2,2)+self.Detector.to3channel(Y3,3)+self.Detector.to3channel(Y4,2)+self.Detector.to3channel(Y5,3)
        '''

        return X

'''
class Biggenerator(nn.Module):
    # initializers
    def __init__(self, G1, G2, G3, G4, G5, Detector, input_size=100, n_class=500):
        super(Biggenerator, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 200)
        
        self.G1=G1.eval()
        self.G2=G2.eval()
        self.G3=G3.eval()
        self.G4=G4.eval()
        self.G5=G5.eval()
        self.Detector=Detector#是denoise
        
    # forward method
    def forward(self, input):
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.tanh(self.fc2(x))
        X1=x[:,0:100]
        X2=x[:,100:200]
        Y1=self.G1(X1)
        Y2=self.G3(X2)
        X=self.Detector(Y1)+self.Detector(Y2)
        return X
    
    def RGBforward(self,input):
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.tanh(self.fc2(x))
        X1=x[:,0:100]
        X2=x[:,100:200]
        Y1=self.G1(X1)
        Y2=self.G3(X2)
        X=self.Detector.to3channel(Y1,1)+self.Detector.to3channel(Y2,3)
        return X
'''
class vanilla_GAN_generator(nn.Module):
    # initializers
    def __init__(self, Detector,input_size=100, n_class = 784):
        super(vanilla_GAN_generator, self).__init__()
        self.fc1 = nn.Linear(100, 256)
        self.fc2 = nn.Linear(self.fc1.out_features, 512)
        self.fc3 = nn.Linear(self.fc2.out_features, 1024)
        self.fc4 = nn.Linear(self.fc3.out_features, n_class)
        self.Detector=Detector
    # forward method
    def forward(self, input):
        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.leaky_relu(self.fc3(x), 0.2)
        x = F.tanh(self.fc4(x))
        return x

    def RGBforward(self,input):

        x = F.leaky_relu(self.fc1(input), 0.2)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = F.leaky_relu(self.fc3(x), 0.2)
        x = F.tanh(self.fc4(x))
        X=self.Detector.to3channel(x,3) 

        return X
