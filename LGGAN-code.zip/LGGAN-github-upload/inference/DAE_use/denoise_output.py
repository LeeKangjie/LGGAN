
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
from torch.autograd import Variable
import scipy.io as sio
import numpy as np
from torchvision.utils import save_image

#K1=np.ones((20,5))
K1=np.ones((12,7))
kernel1=torch.FloatTensor(K1).unsqueeze(0).unsqueeze(0).cuda()
K2=np.ones((5,10))
kernel2=torch.FloatTensor(K2).unsqueeze(0).unsqueeze(0).cuda()
K3=np.ones((5,5))
kernel3=torch.FloatTensor(K3).unsqueeze(0).unsqueeze(0).cuda()

def denoise(input,num):
    
    output=torch.zeros(input.shape[0],28*28).cuda()    
    for i in range(input.shape[0]):
        
        R=Variable(torch.reshape(input[i],(1,1,28,28)),requires_grad=True).cuda()
        R0=torch.zeros(1,1,28,28)
        if num == 1:
            p=F.conv2d(R,kernel1)
            m=torch.argmax(p.squeeze(0).squeeze(0))
            #R0[0][0][m//p.shape[3]:m//p.shape[3]+20,m%p.shape[3]:m%p.shape[3]+5]=1.0
            R0[0][0][m//p.shape[3]:m//p.shape[3]+12,m%p.shape[3]:m%p.shape[3]+7]=1.0
            C1=Variable(torch.Tensor(R0),requires_grad=True) 
            R=C1
        elif num == 2:
            p=F.conv2d(R,kernel2)
            m=torch.argmax(p.squeeze(0).squeeze(0))
            R0[0][0][m//p.shape[3]:m//p.shape[3]+5,m%p.shape[3]:m%p.shape[3]+10]=1.0
            C2=Variable(torch.Tensor(R0),requires_grad=True) 
            R=C2
        elif num == 3:
            p=F.conv2d(R,kernel3)
            m=torch.argmax(p.squeeze(0).squeeze(0))
            R0[0][0][m//p.shape[3]:m//p.shape[3]+5,m%p.shape[3]:m%p.shape[3]+5]=1.0
            C3=Variable(torch.Tensor(R0),requires_grad=True) 
            R=C3
        #save_image(R.cpu(), f"inference/DAE_use/inference_denoise{i}.jpg")
        plt.imshow(R.view(28,28).detach().cpu().numpy(),cmap='bone')
        plt.show()

        output[i]=torch.reshape(R,(1,28*28))
    return output

input = sio.loadmat('inference/DAE_use/save_inference1')
input= torch.FloatTensor(input['matrix'])

output=denoise(input,1).detach().cpu().numpy()
sio.savemat('inference/DAE_use/save_inference1_denoise',{'matrix':output})

input = sio.loadmat('inference/DAE_use/save_inference2')
input= torch.FloatTensor(input['matrix'])

output=denoise(input,2).detach().cpu().numpy()
sio.savemat('inference/DAE_use/save_inference2_denoise',{'matrix':output})


input = sio.loadmat('inference/DAE_use/save_inference3')
input= torch.FloatTensor(input['matrix'])

output=denoise(input,3).detach().cpu().numpy()
sio.savemat('inference/DAE_use/save_inference3_denoise',{'matrix':output})

