
import numpy as np
from PIL import Image
from centernet import CenterNet
from torchvision.utils import save_image
import scipy.io as sio
import torch

if __name__ == "__main__":
    

    model_path='centernet_pytorch_main/logs/Epoch100-Total_Loss1.3992-Val_Loss1.0948.pth'
    centernet = CenterNet(model_path)
    boxes=[]
    for i in range(10):
        image = Image.open("centernet_pytorch_main/img/inference"+str(i)+".jpg")
        box = centernet.detect_image(image,Return_boxes=True)
        #r_image,box = centernet.detect_image(image,Return_boxes=True)
        #r_image.show()
        #r_image.save("./img/object_inference"+str(i)+".jpg")
        boxes.append(box)#len()=10

    heat_source=np.zeros((10,784),dtype=float)
    H=np.zeros((1,784),dtype=float)
    R=np.reshape(H,(28,28))
    for i in range(len(boxes)):
        R[:,:]=0
        for j in range(len(boxes[i])):
            top, left, bottom, right = boxes[i][j]
            px=int(top//20)
            py=int(left//20)
            if bottom-top>20*20*0.8:
                R[px:px+20,py:py+5]=1
            elif right-left>10*20*0.8:
                R[px:px+5,py:py+10]=1
            else:
                R[px:px+5,py:py+5]=1
        test_images=torch.tensor(R)
        H=np.reshape(R,(1,784))
        heat_source[i]=H
        save_image(test_images, f"./img/redraw_inference{i}.jpg")

    sio.savemat('redraw_inference',{'matrix':heat_source})
