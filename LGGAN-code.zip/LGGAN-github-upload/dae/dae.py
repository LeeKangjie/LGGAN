
import torch.nn as nn

class dae(nn.Module):
    def __init__(self):
        super(dae, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(28*28, 650),
            #nn.LeakyReLU(),
            #nn.Linear(600, 400),
            nn.LeakyReLU())
        self.decoder = nn.Sequential(
            #nn.Linear(400,600),
            #nn.LeakyReLU(),
            nn.Linear(650,28*28),
            nn.Sigmoid())

    def forward(self, x):
        x=x.view(-1,28*28)
        x = self.encoder(x)
        x = self.decoder(x)
        return x
