import matplotlib.pyplot as plt
from torchvision.utils import save_image
import torch
from torch.autograd import Variable
import numpy as np
import scipy.io as sio
from PIL import Image
from dae.dae import dae
from model import generator,Biggenerator
import torch.optim as optim
from detector import denoiser
from tune import tune
from centernet_pytorch_main.centernet import CenterNet

G1 = generator(input_size=100, n_class=28*28)
G2 = generator(input_size=100, n_class=28*28)
G3 = generator(input_size=100, n_class=28*28)
G4 = generator(input_size=100, n_class=28*28)
G5 = generator(input_size=100, n_class=28*28)
G1.load_state_dict(torch.load("GAN_results/g1_param.pkl"))
G2.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G3.load_state_dict(torch.load("GAN_results/g3_param.pkl"))
G4.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G5.load_state_dict(torch.load("GAN_results/g3_param.pkl"))

model_path='./dae/net.pth'
dae=dae().cuda()
for p in dae.parameters():
    p.requires_grad = False
dae.load_state_dict(state_dict=torch.load(model_path))
Detector=denoiser(net=dae)
Detector.cuda()


Tune=tune()


for p in G1.parameters():
    p.requires_grad = False
for p in G2.parameters():
    p.requires_grad = False
for p in G3.parameters():
    p.requires_grad = False
for p in G4.parameters():
    p.requires_grad = False
for p in G5.parameters():
    p.requires_grad = False
G = Biggenerator(G1,G2,G3,G4,G5,Detector,input_size=100, n_class=500)
G1.cuda()
G2.cuda()
G3.cuda()
G4.cuda()
G5.cuda()

G1.eval()
G2.eval()
G3.eval()
G4.eval()
G5.eval()
G.cuda()
G.load_state_dict(torch.load("GAN_results/g_param.pkl"))

'''
if __name__ == '__main__':
    with torch.no_grad():
        save_inference=np.zeros((100,28*28*3),dtype=float)
        for i in range(save_inference.shape[0]):
            z_ = torch.randn((1, 100))
            z_ = Variable(z_.cuda(), volatile=True)
            G.eval()
            #test_images = G(z_).cpu()

       
            test_images = G.RGBforward(z_).cpu()
            plt.imshow(test_images)
            plt.show()
            save_inference[i]=test_images.reshape(1,28*28*3).cpu()
            #test_images=save_inference[i].reshape(28,28,3)                 

            #save_image(test_images.cpu(), f"./inference/Centernet_use/{i}.jpg")
            test_images=np.array(np.uint8(test_images.detach().numpy()))
            test_images=Image.fromarray(test_images)
            test_images.save(f"./inference/Centernet_use/{i}.jpg")

        #sio.savemat('./inference/Centernet_use/save_inference',{'matrix':save_inference})
        
        for i in range(save_inference.shape[0]):
            image=Image.open("./inference/Centernet_use/"+str(i)+".jpg")
            image = image.resize((512,512), Image.BICUBIC)
            image.save(f"./inference/Centernet_use/{i}.jpg")
'''        

G = generator(input_size=100, n_class=28*28)
G.cuda()
G.load_state_dict(torch.load("GAN_results/g3_param.pkl"))
if __name__ == '__main__':
    with torch.no_grad():
        save_inference=np.zeros((10,784),dtype=float)
        for i in range(save_inference.shape[0]):
            z_ = torch.randn((1, 100))
            z_ = Variable(z_.cuda(), volatile=True)
            G.eval()
            test_images = G(z_).cpu()
            save_inference[i]=test_images.view(1,28*28)
            test_images=test_images.view(28, 28)
            plt.axis('off')
            plt.imshow(test_images,cmap='Blues')
            #plt.imshow(test_images)
            plt.show()
            #save_image(test_images.cpu(), f"./inference/DAE_use/inference{i}.jpg")
    
        sio.savemat('./inference/DAE_use/save_inference1',{'matrix':save_inference})

