import matplotlib.pyplot as plt
from torchvision.utils import save_image
import torch
from torch.autograd import Variable
import itertools
import numpy as np
import scipy.io as sio
from PIL import Image
from dae.dae import dae
from model import generator,Biggenerator,discriminator,vanilla_GAN_generator
import torch.optim as optim
from detector import denoiser
from tune import tune, tune_LGD3
import torch.nn as nn
import pickle
from centernet_pytorch_main.centernet import CenterNet

G1 = generator(input_size=100, n_class=28*28)
G2 = generator(input_size=100, n_class=28*28)
G3 = generator(input_size=100, n_class=28*28)
G4 = generator(input_size=100, n_class=28*28)
G5 = generator(input_size=100, n_class=28*28)
G1.load_state_dict(torch.load("GAN_results/g1_param.pkl"))
G2.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G3.load_state_dict(torch.load("GAN_results/g3_param.pkl"))
G4.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G5.load_state_dict(torch.load("GAN_results/g3_param.pkl"))
for p in G1.parameters():
    p.requires_grad = False
for p in G2.parameters():
    p.requires_grad = False
for p in G3.parameters():
    p.requires_grad = False
for p in G4.parameters():
    p.requires_grad = False
for p in G5.parameters():
    p.requires_grad = False
G1.cuda()
G2.cuda()
G3.cuda()
G4.cuda()
G5.cuda()
G1.eval()
G2.eval()
G3.eval()
G4.eval()
G5.eval()
model_path='./dae/net.pth'
dae=dae().cuda()
for p in dae.parameters():
    p.requires_grad = False
dae.load_state_dict(state_dict=torch.load(model_path))

Detector=denoiser(net=dae)
Detector.cuda()

G = Biggenerator(G1,G2,G3,G4,G5,Detector,input_size=100, n_class=700)
G.cuda()
G.load_state_dict(torch.load("GAN_results/g_param.pkl"))
#direction_g_param.pkl 
#LGD-1_gan_g_param.pkl


#G = vanilla_GAN_generator(Detector,input_size=100, n_class = 784)
#G.load_state_dict(torch.load("GAN_results/LGD-1_gan_g_param.pkl"))
#G.cuda()


D = discriminator(input_size=28*28, n_class=1)
D.cuda()

G_optimizer = optim.RMSprop(G.parameters(), lr = 0.0002)
D_optimizer = optim.RMSprop(D.parameters(), lr = 0.0002)
BCE_loss = nn.BCELoss()

Tune=tune() 
#Tune=tune_LGD3()


def show_result(num_epoch,  path, show = False, save = False, isFix=False):
    z_ = torch.randn((5*5, 100))
    z_ = Variable(z_.cuda(), volatile=True)

    G.eval()
    test_images = G(z_)
    G.train()

    size_figure_grid = 5
    fig, ax = plt.subplots(size_figure_grid, size_figure_grid, figsize=(5, 5))
    for i, j in itertools.product(range(size_figure_grid), range(size_figure_grid)):
        ax[i, j].get_xaxis().set_visible(False)
        ax[i, j].get_yaxis().set_visible(False)

    for k in range(5*5):
        i = k // 5
        j = k % 5
        ax[i, j].cla()
        ax[i, j].imshow(test_images[k, :].cpu().data.view(28, 28).numpy(), cmap='gray')

    label = 'Epoch {0}'.format(num_epoch)
    fig.text(0.5, 0.04, label, ha='center')
    plt.savefig(path)

    if show:
        plt.show()
    else:
        plt.close()

def fit_one_Biggenerater(train_epoch,train_loader,iter):
    G.train()
    mean_epoch_G_loss=[]
    mean_epoch_D_loss=[]
    for epoch in range(train_epoch):
        D_losses = []
        G_losses = []
        for i, x_ in enumerate(train_loader):

            ## train discriminator
            D.zero_grad()
            for p in D.parameters():
                p.data.clamp_(-0.01, 0.01)
            x_ = x_.view(-1, 28 * 28)
            mini_batch = x_.size()[0]
            
            y_real_ = torch.ones(mini_batch)
            y_fake_ = torch.zeros(mini_batch)
            x_, y_real_, y_fake_ = Variable(x_.cuda()), Variable(y_real_.cuda()), Variable(y_fake_.cuda())
            D_result = D(x_).squeeze()

            D_real_loss = BCE_loss(D_result, y_real_)

            z_ = torch.randn((mini_batch, 100))
            z_ = Variable(z_.cuda())
            G_result=G(z_)

            D_result = D(G_result).squeeze()
            D_fake_loss = BCE_loss(D_result, y_fake_)
            D_train_loss = D_real_loss + D_fake_loss

            #D_result2 = D(G_result).squeeze()
            #D_train_loss=-(torch.mean(D_result)-torch.mean(D_result2))

            D_train_loss.backward()
            D_optimizer.step()
            D_losses.append(D_train_loss.item())  

            ## train generator G
            G.zero_grad()
            z_ = torch.randn((mini_batch, 100))
            y_ = torch.ones(mini_batch)
            z_, y_ = Variable(z_.cuda()), Variable(y_.cuda())
            G_result=G(z_)
            D_result = D(G_result).squeeze()

            G_train_loss = BCE_loss(D_result, y_)
            #G_train_loss= -torch.mean(D_result)

            G_train_loss.backward()
            G_optimizer.step()
            G_losses.append(G_train_loss.item())

        print('[%d/%d]: loss_d: %.3f, loss_g: %.3f' % (
            (epoch + 1), train_epoch, torch.mean(torch.FloatTensor(D_losses)), torch.mean(torch.FloatTensor(G_losses))))
        if epoch%20==0:
            p = 'GAN_results/Main_results/' +str(iter)+'GAN_'+ str(epoch + 1) + '.png'
            show_result((epoch+1), save=True, path=p, isFix=False)

        mean_epoch_G_loss.append(torch.mean(torch.FloatTensor(G_losses)))
        mean_epoch_D_loss.append(torch.mean(torch.FloatTensor(D_losses)))
    #file=open('mean_epoch_G_loss'+str(iter)+'.pickle','wb')
    #pickle.dump(mean_epoch_G_loss,file)
    #file.close()
    #file=open('mean_epoch_D_loss'+str(iter)+'.pickle','wb')
    #pickle.dump(mean_epoch_D_loss,file)
    #file.close()


def gaussian2D(shape, sigma=1):
    m, n = [(ss - 1.) / 2. for ss in shape]
    y, x = np.ogrid[-m:m + 1, -n:n + 1]
    h = np.exp(-(x * x + y * y) / (2 * sigma * sigma))
    h[h < np.finfo(h.dtype).eps * h.max()] = 0
    return h

def draw_gaussian(center,sigma_chu): 
    radius=28*2
    diameter=2 * radius + 1
    gaussian = gaussian2D((diameter, diameter), sigma=diameter / sigma_chu)
    score_map=np.zeros((28,28))
    height, width = 28,28
    for i in range(len(center)):
        x, y = int(center[i][0]), int(center[i][1])
        left, right = min(x, radius), min(width - x, radius + 1)
        top, bottom = min(y, radius), min(height - y, radius + 1)
        masked_gaussian = gaussian[radius - top:radius + bottom, radius - left:radius + right]
        score_map=masked_gaussian+score_map
    return score_map

def evaluater(new_data):#new_data shape: batch_size*784


    #center=[[5,6],[5,11],[5,16],[5,21],[22,6],[22,11],[22,16],[22,21]]
    #center=[[5,7],[5,12],[5,17],[5,22],[13,7],[13,12],[13,17],[13,22]]

    center=[[3,3],[4,10],[3,16],[6,20],[12,21],[18,20],[21,16],[21,10],[22,3]]
    #center=[[20,2],[12,2],[6,8],[10,13],[14,15],[19,19],[12,25],[6,25]]
    #center=[[3,3],[8,3],[14,3],[19,3],[24,3],[14,10],[14,17],[14,24]]


    sigma_chu=38
    score_map=draw_gaussian(center,sigma_chu)
    score_map=score_map.reshape(1,784)
    score=np.zeros(new_data.shape[0])
    save_data=[]
    for i in range (new_data.shape[0]):

        score[i]=sum(sum(score_map*new_data[i]))
        ind=np.argsort(-score)
    for i in range(len(ind)):

        #save_data.append(new_data[ind[i]])
        if sum(new_data[ind[i]])==25*7:
           save_data.append(new_data[ind[i]])
        
    return np.array(save_data[0:300])

def evaluater_LGD_3(new_data,scorez):
    ind=np.argsort(-scorez)
    save_data=[]
    for i in range(len(ind)):
        save_data.append(new_data[ind[i]])        
    return np.array(save_data[0:300])


batch_size=128
train_epoch=200

if __name__ == '__main__':
    
    for iter in range(10):
        #*********************************Step1 train Biggenerator*********************************#
        if iter==0:
            date=sio.loadmat("./dataset/random_layout_1K_7c")
            date = date['matrix']
            date = torch.FloatTensor(np.array(date.todense()))
            train_loader = torch.utils.data.DataLoader(date,batch_size=batch_size, shuffle=True)
        else:
            date=sio.loadmat("./dataset/new_data"+str(iter-1))
            date = date['matrix']
            date = torch.FloatTensor(np.array(date))
            train_loader = torch.utils.data.DataLoader(date,batch_size=batch_size, shuffle=True)
        
        fit_one_Biggenerater(train_epoch=train_epoch,train_loader=train_loader,iter=iter)
        print("fit_Biggenerater"+str(iter)+"train finished")
        #**********************Step2 genarate new samples using Biggenerator***********************#
        with torch.no_grad():
            new_data=np.zeros((1000,28*28),dtype=float)
            scorez=np.zeros((1000,1),dtype=float)
            for i in range(new_data.shape[0]):
                z_ = torch.randn((1, 100))
                z_ = Variable(z_.cuda(), volatile=True)
                G.eval()
                
                test_images = G.RGBforward(z_).cpu()
                #plt.imshow(test_images)
                #plt.show()

                #RGB_layout,Binary_layout,score=Tune(test_images)
                #scorez[i]=score

                RGB_layout,Binary_layout=Tune(test_images)
                #RGB_layout=RGB_layout.reshape(28,28,3).cpu()
                #plt.imshow(RGB_layout)
                #plt.show()
                
                #Binary_layout=G(z_).cpu()

                new_data[i]=Binary_layout
                
            #*********************Step3 evaluate and updata new dataset****************************#
            #save_data=evaluater_LGD_3(new_data,scorez)

            save_data=evaluater(new_data)
            #save_data=new_data[0:300]

            sio.savemat('./dataset/all_new_data'+str(iter),{'matrix':new_data})
            sio.savemat('./dataset/new_data'+str(iter),{'matrix':save_data})
            #****************************Step4 save generator results******************************#
            print("Training finish!... save training results")
            torch.save(G.state_dict(), "GAN_results/u_g_param.pkl")
    
    
    G.load_state_dict(torch.load("GAN_results/u_g_param.pkl"))
    C=0
    for i in range(1000):
        z_ = torch.randn((1, 100))
        z_ = Variable(z_.cuda(), volatile=True)
        G.eval()
        test_images = G.RGBforward(z_).cpu()
        #plt.imshow(test_images)
        #plt.show()
        RGB_layout,Binary_layout=Tune(test_images)
        a=sum(sum(Binary_layout.cpu()))
        if sum(sum(Binary_layout.cpu()))==25*7:
            C=C+1
            RGB_layout=RGB_layout.reshape(28,28,3)/255
            #plt.imshow(RGB_layout)
            #plt.show()
            save_image(RGB_layout.permute(2,0,1), f"./GAN_results\Main_results"+str(C)+".jpg")
        if C==30:
            break
    
