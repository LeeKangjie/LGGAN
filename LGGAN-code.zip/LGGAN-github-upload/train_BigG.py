import os
import matplotlib.pyplot as plt
import itertools
import pickle
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
import scipy.io as sio
import numpy as np
from model import generator,discriminator,Biggenerator,vanilla_GAN_generator
from centernet_pytorch_main.centernet import CenterNet
from dae.dae import dae
from detector import detector,spdetector,denoiser

# fixed noise
fixed_z_ = torch.randn((5 * 5, 100))    
fixed_z_ = Variable(fixed_z_.cuda(), volatile=True)

# results save folder
if not os.path.isdir('GAN_results'):
    os.mkdir('GAN_results')
if not os.path.isdir('GAN_results/Random_results'):
    os.mkdir('GAN_results/Random_results')
if not os.path.isdir('GAN_results/Fixed_results'):
    os.mkdir('GAN_results/Fixed_results')

# training parameters
batch_size = 128
lr = 0.0002
train_epoch = 2000

layout=sio.loadmat("./dataset/random_lGD3_layout_1K")
layout = layout['matrix']
random_layout = torch.FloatTensor(np.array(layout.todense()))
train_loader = torch.utils.data.DataLoader(random_layout,batch_size=batch_size, shuffle=True)


G1 = generator(input_size=100, n_class=28*28)
G2 = generator(input_size=100, n_class=28*28)
G3 = generator(input_size=100, n_class=28*28)
G4 = generator(input_size=100, n_class=28*28)
G5 = generator(input_size=100, n_class=28*28)
G1.load_state_dict(torch.load("GAN_results/g1_param.pkl"))
G2.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G3.load_state_dict(torch.load("GAN_results/g3_param.pkl"))
G4.load_state_dict(torch.load("GAN_results/g2_param.pkl"))
G5.load_state_dict(torch.load("GAN_results/g3_param.pkl"))


'''
model_path='./centernet_pytorch_main/logs/Epoch100-Total_Loss1.3992-Val_Loss1.0948.pth'
centernet = CenterNet(model_path)
Detector=detector(net=centernet)
'''
'''
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#with torch.no_grad():
K1=np.ones((20,5))
kernel1=torch.FloatTensor(K1).unsqueeze(0).unsqueeze(0).cuda()
K2=np.ones((5,10))
kernel2=torch.FloatTensor(K2).unsqueeze(0).unsqueeze(0).cuda()
K3=np.ones((5,5))
kernel3=torch.FloatTensor(K3).unsqueeze(0).unsqueeze(0).cuda()
Detector=spdetector(kernel1,kernel2,kernel3)
'''

model_path='./dae/net.pth'
dae=dae().cuda()
for p in dae.parameters():
    p.requires_grad = False
dae.load_state_dict(state_dict=torch.load(model_path))
Detector=denoiser(net=dae)
Detector.cuda()

#for p in Detector.parameters():
#    p.requires_grad = False


for p in G1.parameters():
    p.requires_grad = False
for p in G2.parameters():
    p.requires_grad = False
for p in G3.parameters():
    p.requires_grad = False
for p in G4.parameters():
    p.requires_grad = False
for p in G5.parameters():
    p.requires_grad = False

#G = Biggenerator(G1,G2,G3,G4,G5,Detector,input_size=100, n_class=500)
G = Biggenerator(G1,G2,G3,G4,G5,Detector,input_size=100, n_class=200)

#G = vanilla_GAN_generator(Detector,input_size=100, n_class = 784)


D = discriminator(input_size=28*28, n_class=1)
G1.cuda()
G2.cuda()
G3.cuda()
G4.cuda()
G5.cuda()

G1.eval()
G2.eval()
G3.eval()
G4.eval()
G5.eval()

G.cuda()
D.cuda()

#Optimizer
#G_optimizer = optim.Adam(G.parameters(), lr=lr)
#D_optimizer = optim.Adam(D.parameters(), lr=lr)

G_optimizer = optim.RMSprop(G.parameters(), lr=lr)
D_optimizer = optim.RMSprop(D.parameters(), lr=lr)


#if True:
#   G.load_state_dict(torch.load("GAN_results/g_param.pkl"))
#   D.load_state_dict(torch.load("GAN_results/d_param.pkl"))

# Binary Cross Entropy loss
BCE_loss = nn.BCELoss()

def show_result(num_epoch,  path, show = False, save = False, isFix=False):
    z_ = torch.randn((5*5, 100))
    z_ = Variable(z_.cuda(), volatile=True)

    G.eval()
    if isFix:
        test_images = G(fixed_z_)
    else:
        test_images = G(z_)
    G.train()

    size_figure_grid = 5
    fig, ax = plt.subplots(size_figure_grid, size_figure_grid, figsize=(5, 5))
    for i, j in itertools.product(range(size_figure_grid), range(size_figure_grid)):
        ax[i, j].get_xaxis().set_visible(False)
        ax[i, j].get_yaxis().set_visible(False)

    for k in range(5*5):
        i = k // 5
        j = k % 5
        ax[i, j].cla()
        ax[i, j].imshow(test_images[k, :].cpu().data.view(28, 28).numpy(), cmap='gray')

    label = 'Epoch {0}'.format(num_epoch)
    fig.text(0.5, 0.04, label, ha='center')
    plt.savefig(path)

    if show:
        plt.show()
    else:
        plt.close()

def show_train_hist(hist, path, show = False, save = False):
    x = range(len(hist['D_losses']))

    y1 = hist['D_losses']
    y2 = hist['G_losses']

    plt.plot(x, y1, label='D_loss')
    plt.plot(x, y2, label='G_loss')

    plt.xlabel('Epoch')
    plt.ylabel('Loss')

    plt.legend(loc=4)
    plt.grid(True)
    plt.tight_layout()

    if save:
        plt.savefig(path)

    if show:
        plt.show()
    else:
        plt.close()

train_hist = {}
train_hist['D_losses'] = []
train_hist['G_losses'] = []

if __name__ == '__main__':

    torch.autograd.set_detect_anomaly(True)

    for epoch in range(train_epoch):
        D_losses = []
        G_losses = []

        for i, x_ in enumerate(train_loader):

            ## train discriminator/critic D
            D.zero_grad()
            
            for p in D.parameters():
                p.data.clamp_(-0.01, 0.01)
            
            x_ = x_.view(-1, 28 * 28)
            mini_batch = x_.size()[0]
            
            y_real_ = torch.ones(mini_batch)
            y_fake_ = torch.zeros(mini_batch)
            x_, y_real_, y_fake_ = Variable(x_.cuda()), Variable(y_real_.cuda()), Variable(y_fake_.cuda())
            D_result = D(x_).squeeze()
            D_real_loss = BCE_loss(D_result, y_real_)

            z_ = torch.randn((mini_batch, 100))
            z_ = Variable(z_.cuda())
            #z1,z2,z3 = G(z_)
            #G_result=G1(z1)+G2(z2)+G3(z3)
            G_result=G(z_)
            D_result = D(G_result).squeeze()
            D_fake_loss = BCE_loss(D_result, y_fake_)

            D_train_loss = D_real_loss + D_fake_loss
            D_train_loss.backward()
            D_optimizer.step()
            D_losses.append(D_train_loss.item())  

            # train generator G
            G.zero_grad()
            z_ = torch.randn((mini_batch, 100))
            y_ = torch.ones(mini_batch)
            z_, y_ = Variable(z_.cuda()), Variable(y_.cuda())
            G_result=G(z_)
            D_result = D(G_result).squeeze()
            G_train_loss = BCE_loss(D_result, y_)
            G_train_loss.backward()
            G_optimizer.step()
            G_losses.append(G_train_loss.item())

        print('[%d/%d]: loss_d: %.3f, loss_g: %.3f' % (
            (epoch + 1), train_epoch, torch.mean(torch.FloatTensor(D_losses)), torch.mean(torch.FloatTensor(G_losses))))
        
        if epoch%100==0:
            p = 'GAN_results/Random_results/GAN_' + str(epoch + 1) + '.png'
            fixed_p = 'GAN_results/Fixed_results/GAN_' + str(epoch + 1) + '.png'
            show_result((epoch+1), save=True, path=p, isFix=False)
            show_result((epoch+1), save=True, path=fixed_p, isFix=True)
            train_hist['D_losses'].append(torch.mean(torch.FloatTensor(D_losses)))
            train_hist['G_losses'].append(torch.mean(torch.FloatTensor(G_losses)))


    if True:
        print("Training finish!... save training results")
        #torch.save(G.state_dict(), "GAN_results/g_param.pkl")
        #torch.save(D.state_dict(), "GAN_results/d_param.pkl")

        torch.save(G.state_dict(), "GAN_results/LGD-1_gan_g_param.pkl")
        
        with open('GAN_results/train_hist.pkl', 'wb') as f:
            pickle.dump(train_hist, f)
        show_train_hist(train_hist, save=True, path='GAN_results/train_hist.png')

