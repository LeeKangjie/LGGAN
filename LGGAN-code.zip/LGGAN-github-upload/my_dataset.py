import numpy as np
import pickle as pkl
import scipy.sparse as sp
import scipy.io as sio
import random
import torch
def random_layout():
    heat_source=np.zeros((10000,784),dtype=float)
    for i in range(heat_source.shape[0]):
        print("number",i)
        H=np.zeros((1,784),dtype=float)
        R=np.reshape(H,(28,28))

        while np.sum(R)!=25*7:
            R[:,:]=0
            H[:,:]=0
            '''
            p1,p2,p3=random.sample(range(0,784),3)
            p1x=p1//28
            p1y=p1%28 
            p2x=p2//28
            p2y=p2%28 
            p3x=p3//28
            p3y=p3%28 
            R[p1x:p1x+20,p1y:p1y+5]=1
            R[p2x:p2x+5,p2y:p2y+10]=1
            R[p3x:p3x+5,p3y:p3y+5]=1
            '''
            '''
            p1,p2,p3,p4,p5=random.sample(range(0,784),5)
            #p1,p2,p3,p4,p5=random.sample(range(0,300),5)
            p1x=p1//28
            p1y=p1%28 
            p2x=p2//28
            p2y=p2%28 
            p3x=p3//28
            p3y=p3%28 
            p4x=p4//28
            p4y=p4%28
            p5x=p5//28
            p5y=p5%28            
            R[p1x:p1x+12,p1y:p1y+7]=1
            R[p2x:p2x+5,p2y:p2y+10]=1
            R[p3x:p3x+5,p3y:p3y+5]=1
            R[p4x:p4x+5,p4y:p4y+10]=1
            R[p5x:p5x+5,p5y:p5y+5]=1
            '''
            
            
            p1,p2,p3,p4,p5,p6,p7=random.sample(range(0,784),7)
            p1x=p1//28
            p1y=p1%28 
            p2x=p2//28
            p2y=p2%28 
            p3x=p3//28
            p3y=p3%28 
            p4x=p4//28
            p4y=p4%28
            p5x=p5//28
            p5y=p5%28    
            p6x=p6//28
            p6y=p6%28
            p7x=p7//28
            p7y=p7%28   
        
            R[p1x:p1x+5,p1y:p1y+5]=1
            R[p2x:p2x+5,p2y:p2y+5]=1
            R[p3x:p3x+5,p3y:p3y+5]=1
            R[p4x:p4x+5,p4y:p4y+5]=1
            R[p5x:p5x+5,p5y:p5y+5]=1
            R[p6x:p6x+5,p6y:p6y+5]=1
            R[p7x:p7x+5,p7y:p7y+5]=1
            
            
            '''
            [p1]=random.sample(range(0,784),1)
            p1x=p1//28
            p1y=p1%28 
            R[p1x:p1x+12,p1y:p1y+7]=1
            '''
            '''
            p1,p2=random.sample(range(0,784),2)
            p1x=p1//28
            p1y=p1%28 
            p2x=p2//28
            p2y=p2%28 
            R[p1x:p1x+12,p1y:p1y+7]=1
            R[p2x:p2x+5,p2y:p2y+5]=1
            '''
            '''
            p1,p2,p3,p4,p5,p6=random.sample(range(0,784),6)
            p1x=p1//28
            p1y=p1%28
            p2x=p2//28
            p2y=p2%28
            p3x=p3//28
            p3y=p3%28 
            p4x=p4//28
            p4y=p4%28 
            p5x=p5//28
            p5y=p5%28 
            p6x=p6//28
            p6y=p6%28 
            R[p1x:p1x+5,p1y:p1y+5]=1
            R[p2x:p2x+5,p2y:p2y+5]=1
            R[p3x:p3x+5,p3y:p3y+5]=1
            R[p4x:p4x+5,p4y:p4y+5]=1
            R[p5x:p5x+5,p5y:p5y+5]=1 
            R[p6x:p6x+5,p6y:p6y+5]=1            
            '''        
            
        H=np.reshape(R,(1,784))
        heat_source[i]=H
    X=sp.csc_matrix(heat_source/1.0)
    sio.savemat('random_layout_10K_7_square_component',{'matrix':X})#


random_layout()

from torchvision.utils import save_image
import torch
import scipy.io as sio
import numpy as np
X = sio.loadmat('./dataset/random_layout_1K_1_square_component')
X= X['matrix']
X=X.todense()
for i in range(30):
    R=np.reshape(X[i],(28,28))
    save_image(torch.tensor(R), f"./img/new_data/"+str(i)+".jpg")

    
    
